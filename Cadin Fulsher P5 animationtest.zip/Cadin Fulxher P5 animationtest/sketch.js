let stars = []; // Store star positions
let glowSize = 1; // Portal glow pulsing size
let glowDirection = 1; // Pulsing direction
let rotationAngle = 0; // Rotation angle for lines
let rotating = false; // Track if rotation should occur
let squareX = 0; // Moving square's X position
function setup() {
  createCanvas(400, 400);
  // Generate static star positions
  for (let i = 0; i < 100; i++) {
    let x = random(width);
    let y = random(height);
    stars.push({ x: x, y: y });
  }
}
function draw() {
  background(0); // Black background for space effect
  // Draw stars
  stroke(255);
  strokeWeight(1);
  for (let star of stars) {
    point(star.x, star.y);
  }
  // Draw gradient "ground"
  for (let y = 300; y < 400; y++) {
    let grayShade = map(y, 300, 400, 180, 80); // Gradient from light to dark gray
    stroke(grayShade);
    line(0, y, 400, y);
  }
  // Draw moving orange square
  fill(255, 140, 0); // Orange color
  noStroke();
  square(squareX, 350, 40); // Square moves horizontally
  // Draw square (behind other shapes)
  fill(100, 15, 55); // Dark color for square
  rectMode(CENTER);
  square(200, 200, 200);
  // Draw "portal" triangle
  noStroke();
  for (let i = 10; i > 0; i--) {
    let colorShade = map(i, 0, 10, 255, 100); // Gradient effect from bright to dim
    fill(255, 105, 180, colorShade); // Hot pink with transparency
    triangle(100 - i, 300 + i, 200, 50 - i, 300 + i, 300 + i);
  }
  // Outer glow effect for the portal
  noFill();
  stroke(255, 105, 180, 100); // Semi-transparent pink
  strokeWeight(glowSize);
  triangle(100, 300, 200, 50, 300, 300);
  // Update glow size for pulsing effect
  glowSize += glowDirection * 0.5;
  if (glowSize > 10 || glowSize < 1) {
    glowDirection *= -1; // Reverse direction when reaching size limits
  }
  // Draw circle with a radial gradient
  let radius = 90;
  for (let r = radius; r > 0; r--) {
    let colorShade = map(r, 0, radius, 255, 5); // Gradient from white to dark blue
    fill(0, 5, colorShade);
    noStroke();
    ellipse(200, 200, r * 2, r * 2);
  }
  // Radiating lines (in front of the circle)
  let numLines = 30;
  push();
  translate(200, 200); // Move to center of square
  if (rotating) {
    rotationAngle += 0.05; // Increment rotation when clicked
  }
  rotate(rotationAngle);
  for (let i = 0; i < numLines; i++) {
    push();
    rotate((TWO_PI * i) / numLines);
    strokeWeight(3); // Thick lines
    if (i % 3 === 0) {
      stroke(255, 0, 0); // Red
    } else if (i % 3 === 1) {
      stroke(255, 255, 0); // Yellow
    } else {
      stroke(255, 165, 0); // Orange
    }
    line(0, 0, 200, 0); // Extend lines outward
    pop();
  }
  pop();
}
// Handle mouse clicks
function mousePressed() {
  rotating = !rotating; // Toggle rotation on click
  // Move square to the right each click
  squareX += 50;
  if (squareX > width) {
    squareX = -40; // Reset to the left when it moves off screen
  }
}