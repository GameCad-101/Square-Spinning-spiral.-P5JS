let figureX = 100;
let figureY = 350;
let figureSpeed = 3;

function setup() {
  createCanvas(700, 450);
}

function draw() {
  background(100, 150, 200);
  drawSun();
  drawClouds();
  drawGrass();
  drawFigure();
  handleMovement();
}
function drawClouds() {
  fill(255);
  noStroke();
  
  // Fixed cloud positions for a still cloudy day
  let cloudPositions = [
    [100, 80], [180, 90], [250, 100],
    [350, 70], [400, 110], [500, 85],
    [600, 95], [50, 130], [300, 140],
    [450, 150]
  ];

  for (let i = 0; i < cloudPositions.length; i++) {
    let x = cloudPositions[i][0];
    let y = cloudPositions[i][1];
    ellipse(x, y, 60, 40);
    ellipse(x + 20, y, 70, 50);
    ellipse(x + 40, y, 60, 40);
  }
}
function drawGrass() {
  for (let y = 350; y < 450; y++) {
    let c = lerpColor(color(50, 150, 50), color(100, 200, 100), (y - 350) / 100);
    stroke(c);
    line(0, y, width, y);
  }
}
function drawSun() {
  noStroke();
  for (let r = 50; r > 0; r--) {
    fill(255, 255, 100, r * 2);
    ellipse(600, 100, r * 4);
  }
  fill(255, 255, 0);
  ellipse(600, 100, 80);
}

function drawFigure() {
  // Body
  stroke(0);
  strokeWeight(2);
  line(figureX, figureY,figureX, figureY - 30); // Body
  
  // Legs
  line(figureX, figureY, figureX - 10, figureY + 20); // Left leg
  line(figureX,figureY, figureX + 10, figureY + 20); // Right leg
  // Arms
  line(figureX, figureY - 20, figureX - 10, figureY - 30); // Left arm
  line(figureX, figureY - 20, figureX + 10, figureY - 30); // Right arm
  
  // Head
  fill(0);
  ellipse(figureX,figureY - 40, 15, 15); // Head
}

function handleMovement() {
  if (keyIsDown(LEFT_ARROW)) {
    figureX -=figureSpeed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    figureX += figureSpeed;
  }
  // Keep the figure on the ground
  figureX = constrain(figureX, 0, width);
}